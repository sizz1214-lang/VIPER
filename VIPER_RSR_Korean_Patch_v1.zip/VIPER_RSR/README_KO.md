# VIPER RSR DVD 한국어 Windows 패처 v1

기존 Win9x VIPER 패처들과 같은 방식으로 원본을 정확히 식별하고, `RSR.EXE`, `SGS.EXE`, `SGS.DAT` 세 파일만 한국어 최종본으로 바꾸는 단일 PE32 패처입니다. 별도 DLL은 필요하지 않습니다.

## 사용법

1. `VIPER_RSR_Korean_Patch.exe`를 실행합니다.
2. VIPER RSR DVD가 설치된 폴더, 즉 `RSR.EXE`, `SGS.EXE`, `SGS.DAT`가 함께 있는 폴더를 선택합니다.
3. 확인 창에서 적용을 승인합니다.
4. 원본 세 파일은 게임 폴더의 `VIPER_RSR_KO_BACKUP`에 자동 보존됩니다.

정확한 최종본에 다시 실행하면 이미 적용됐다고 판정합니다. 패치된 폴더에 다시 실행하면 검증된 백업으로 원본을 복원할 수 있습니다. 다른 버전이나 파일이 섞인 폴더에는 적용하지 않습니다.

명령행에서도 사용할 수 있습니다.

```bat
VIPER_RSR_Korean_Patch.exe --inspect "D:\Games\VIPER RSR" --report inspect.json
VIPER_RSR_Korean_Patch.exe --apply "D:\Games\VIPER RSR" --report apply.json
VIPER_RSR_Korean_Patch.exe --restore "D:\Games\VIPER RSR" --report restore.json
```

## 적용 내용

- `RSR.EXE`: DVD 검사 실패 분기 수정
- `SGS.EXE`: CP949·한글 문자셋·한국어 글꼴 경로와 비일본어 OS 실행 경로 수정
- `SGS.DAT`: 대사 1,704개, 화자명 156개, 선택지 2개를 포함한 1,862개 슬롯 한국어화

패처 SHA-256: `c8a55506682ed28b9e04a8258194868a035f58505d0b4d8726317a851e955c51`

## 검증 범위

고정 오프셋 레코드 재적용으로 세 최종 파일의 봉인 해시를 재현했고, SGS 아카이브 2,020개 엔트리를 다시 읽어 대상 WIN 18개만 변경, 나머지 2,002개 동일, 30개 분기 토폴로지 동일, 번역 슬롯 1,862개와 일본어 잔존 0을 확인했습니다. Wine 임시 복사본에서 원본 식별, 적용, 재적용, 혼합 상태 완료, 정확한 백업, 복원, 오입력 거부, 임시 파일 정리를 통과했습니다.

Wine에서 런처와 SGS 엔진 진입은 확인됐지만 구형 DirectDraw 화면이 검게 캡처되어 한국어 글리프의 직접 시각 검증은 완료되지 않았습니다. 이 항목은 패처 동작 통과와 별개입니다.
