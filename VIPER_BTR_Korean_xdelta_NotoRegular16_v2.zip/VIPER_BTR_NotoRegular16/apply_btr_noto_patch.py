#!/usr/bin/env python3
"""Apply the VIPER BTR Korean HDI patch and install the bundled Noto font."""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path


SOURCE_HDI_SHA256 = "dbc91f5d15eb7fb5400b6c82bc904223eb03f186280e8e7d94dede65cb755ef0"
TARGET_HDI_SHA256 = "6c9fde1b237bf9dcb003b85a379264e2a4a53b2815aeb2809d9c458b3de0e479"
PATCH_SHA256 = "1385e9eb6624693f5e4cde98887e0481d20104091684817bb6e313b501cf6379"
FONT_SHA256 = "73c354b307fce0098c9f49738199fd286cacb9352277c55a39648e0f5e2cd585"


class PatchError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify(path: Path, expected: str, label: str) -> None:
    if not path.is_file():
        raise PatchError(f"{label} 파일을 찾지 못했습니다: {path}")
    actual = sha256(path)
    if actual != expected:
        raise PatchError(
            f"{label} 해시가 맞지 않습니다.\n"
            f"  기대값: {expected}\n"
            f"  실제값: {actual}\n"
            "다른 버전이거나 이미 수정된 파일에는 적용하지 않습니다."
        )


def find_xdelta(script_dir: Path) -> str:
    names = ("xdelta3.exe", "xdelta3") if os.name == "nt" else ("xdelta3",)
    for name in names:
        candidate = script_dir / name
        if candidate.is_file():
            return str(candidate)
    command = shutil.which("xdelta3")
    if command:
        return command
    raise PatchError(
        "xdelta3를 찾지 못했습니다. Windows에서는 xdelta3.exe를 이 폴더에 두고, "
        "Linux에서는 xdelta3 패키지를 설치하십시오."
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="VIPER BTR 일본어 원본 HDI에 한국어 xdelta를 적용합니다."
    )
    parser.add_argument("hdi", type=Path, help="원본 ROMS/Viper BTR.hdi")
    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        default=Path("patched_output"),
        help="출력 폴더(기본값: ./patched_output)",
    )
    args = parser.parse_args()
    script_dir = Path(__file__).resolve().parent
    patch = script_dir / "Viper_BTR_Korean_Final_v1.xdelta"
    bundled_font = script_dir / "font.bmp"
    output_dir = args.output_dir.resolve()
    output_hdi = output_dir / "Viper BTR_kor.hdi"
    output_font = output_dir / "font.bmp"

    try:
        source = args.hdi.resolve()
        verify(source, SOURCE_HDI_SHA256, "HDI 원본")
        verify(patch, PATCH_SHA256, "HDI 패치")
        verify(bundled_font, FONT_SHA256, "동봉 Noto 폰트")
        xdelta = find_xdelta(script_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if output_hdi.exists():
            verify(output_hdi, TARGET_HDI_SHA256, "기존 HDI 출력")
            print(f"[통과] {output_hdi.name}: 이미 정확한 최종본입니다.")
        else:
            temporary = output_hdi.with_name(
                f".{output_hdi.name}.{uuid.uuid4().hex}.building"
            )
            try:
                result = subprocess.run(
                    [xdelta, "-d", "-f", "-s", str(source), str(patch), str(temporary)],
                    capture_output=True,
                    text=True,
                )
                if result.returncode != 0:
                    raise PatchError(
                        f"xdelta 적용 실패(종료 코드 {result.returncode}):\n"
                        f"{result.stderr[:1000]}"
                    )
                verify(temporary, TARGET_HDI_SHA256, "HDI 적용 결과")
                os.replace(temporary, output_hdi)
            finally:
                if temporary.exists():
                    temporary.unlink()
            print(f"[통과] {output_hdi.name}: {TARGET_HDI_SHA256}")

        if output_font.exists():
            verify(output_font, FONT_SHA256, "기존 폰트 출력")
            print(f"[통과] {output_font.name}: 이미 정확한 동봉 폰트입니다.")
        else:
            temporary_font = output_font.with_name(
                f".{output_font.name}.{uuid.uuid4().hex}.building"
            )
            try:
                shutil.copyfile(bundled_font, temporary_font)
                verify(temporary_font, FONT_SHA256, "복사된 폰트")
                os.replace(temporary_font, output_font)
            finally:
                if temporary_font.exists():
                    temporary_font.unlink()
            print(f"[통과] {output_font.name}: {FONT_SHA256}")
    except PatchError as error:
        print(f"[실패] {error}", file=sys.stderr)
        return 3

    print(f"완료: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
