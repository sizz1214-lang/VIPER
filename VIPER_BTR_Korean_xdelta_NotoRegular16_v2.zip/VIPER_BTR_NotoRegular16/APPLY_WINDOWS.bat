@echo off
setlocal
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0apply_btr_noto_patch.py" %*
) else (
  python "%~dp0apply_btr_noto_patch.py" %*
)
exit /b %errorlevel%
