#!/bin/sh
exec python3 "$(dirname "$0")/apply_btr_noto_patch.py" "$@"
