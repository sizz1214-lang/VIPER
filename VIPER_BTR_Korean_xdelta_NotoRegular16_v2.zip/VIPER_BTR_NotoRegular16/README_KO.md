# VIPER BTR 한국어 xdelta · Noto Regular 16 변형판 v2

일본어 원본 HDI에 한국어 번역을 적용하는 xdelta와, 요청한 Noto Regular 16 기반
`font.bmp`를 함께 넣은 별도 변형판입니다. 완성 게임 HDI는 포함하지 않습니다.

## 필요한 원본

- `ROMS/Viper BTR.hdi` — 20,786,176바이트
- SHA-256 `dbc91f5d15eb7fb5400b6c82bc904223eb03f186280e8e7d94dede65cb755ef0`

입력 해시가 다르면 자동 적용기는 아무 파일도 덮어쓰지 않고 중단합니다.

## 자동 적용

`xdelta3`가 필요합니다. Windows에서는 `xdelta3.exe`를 이 폴더에 두고 실행합니다.

```bat
APPLY_WINDOWS.bat "D:\Viper BTR\ROMS\Viper BTR.hdi" -o "D:\Viper BTR\patched_output"
```

Linux에서는 다음처럼 실행합니다.

```sh
./apply_linux.sh "/path/ROMS/Viper BTR.hdi" -o "/path/patched_output"
```

출력은 `Viper BTR_kor.hdi`와 `font.bmp`입니다.

## 수동 적용

```sh
xdelta3 -d -s "Viper BTR.hdi" "Viper_BTR_Korean_Final_v1.xdelta" "Viper BTR_kor.hdi"
```

동봉된 `font.bmp`는 수정하지 말고 그대로 사용하십시오.

## Anex86 설정

1. `Viper BTR_kor.hdi`를 `ROMS` 폴더에 둡니다.
2. 동봉 `font.bmp`를 `anex86.exe` 옆 또는 원하는 폴더에 둡니다.
3. Anex86의 HDD1에는 한국어 HDI를, Font에는 이 `font.bmp`를 직접 지정합니다.

## 결과 해시

- 한국어 HDI: `6c9fde1b237bf9dcb003b85a379264e2a4a53b2815aeb2809d9c458b3de0e479`
- xdelta: `1385e9eb6624693f5e4cde98887e0481d20104091684817bb6e313b501cf6379`
- 동봉 `font.bmp`: `73c354b307fce0098c9f49738199fd286cacb9352277c55a39648e0f5e2cd585`

폰트는 2048×2048 1bpp BMP이며, KS X 1001 한글 2,350칸을 Noto Sans CJK
Regular 16픽셀로 렌더링했습니다. 빈 한글 칸 0, 한글 영역 밖 변경 0, 동일 조건
재생성 일치를 확인했습니다.

## 검증 상태

- HDI 번역 데이터와 xdelta: 정적·readback 검증 통과
- 이 HDI의 기존 봉인 폰트 조합: Anex86에서 읽을 수 있는 한국어 대사 확인
- 이 정확한 Noto `font.bmp` 조합: **런타임 확인 대기(RC)**

따라서 이 묶음은 사용자가 선택한 폰트 변형판 RC입니다. 실제 Anex86 화면에서 확인되기
전까지 기존 런타임 검증 폰트와 같은 상태로 간주하지 않습니다. 메뉴 전 FMX/SGS 초기화
문구 일부는 일본어로 남아 있습니다.

폰트 출처와 SIL Open Font License는 `FONT_PROVENANCE_AND_LICENSE.txt`를 확인하십시오.
