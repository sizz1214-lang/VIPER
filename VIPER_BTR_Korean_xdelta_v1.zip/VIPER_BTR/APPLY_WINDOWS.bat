@echo off
setlocal
where py >nul 2>nul
if not errorlevel 1 goto use_py
where python >nul 2>nul
if errorlevel 1 goto no_python
python "%~dp0apply_btr_patch.py" %*
goto done
:use_py
py -3 "%~dp0apply_btr_patch.py" %*
:done
set rc=%errorlevel%
pause
exit /b %rc%
:no_python
echo [FAIL] Python 3 was not found. See README_KO.md for manual xdelta commands.
pause
exit /b 2
