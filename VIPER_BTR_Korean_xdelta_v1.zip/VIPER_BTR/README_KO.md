# VIPER BTR 한국어 xdelta v1

게임 HDI와 Anex86용 한글 폰트를 함께 만드는 별도 패치입니다. 게임 이미지나 완성 폰트는 포함하지 않습니다.

## 필요한 원본

- `ROMS/Viper BTR.hdi` — 20,786,176바이트, SHA-256 `dbc91f5d15eb7fb5400b6c82bc904223eb03f186280e8e7d94dede65cb755ef0`
- `FONT.BMP` — 524,350바이트, SHA-256 `acc7a7713c8142e5a1256783502f3ecce06873a46b160c2d00956ff977955660`

원본 묶음에 있던 `hangul.bmp`가 아니라 `FONT.BMP`를 폰트 입력으로 지정해야 합니다. 입력 해시가 다르면 적용기는 아무 파일도 덮어쓰지 않고 중단합니다.

## 자동 적용

`xdelta3`가 필요합니다. Windows에서는 `xdelta3.exe`를 이 폴더에 두고 다음처럼 실행합니다.

```bat
APPLY_WINDOWS.bat "D:\Viper BTR\ROMS\Viper BTR.hdi" "D:\Viper BTR\FONT.BMP" -o "D:\Viper BTR\patched_output"
```

Linux에서는 다음처럼 실행합니다.

```sh
./apply_linux.sh "/path/ROMS/Viper BTR.hdi" "/path/FONT.BMP" -o "/path/patched_output"
```

출력은 `Viper BTR_kor.hdi`와 `hangul.bmp`입니다.

## 수동 적용

```sh
xdelta3 -d -s "Viper BTR.hdi" "Viper_BTR_Korean_Final_v1.xdelta" "Viper BTR_kor.hdi"
xdelta3 -d -s "FONT.BMP" "Viper_BTR_Korean_Font_v1.xdelta" "hangul.bmp"
```

## Anex86 설정

1. `Viper BTR_kor.hdi`를 `ROMS` 폴더에 둡니다.
2. `hangul.bmp`를 `anex86.exe` 옆에 둡니다.
3. Anex86의 HDD1에는 `Viper BTR_kor.hdi`, Font에는 `hangul.bmp`를 지정합니다.
4. 일본어용 `FONT.BMP`를 Font로 선택하면 한국어가 깨집니다.

완성 HDI의 SHA-256은 `6c9fde1b237bf9dcb003b85a379264e2a4a53b2815aeb2809d9c458b3de0e479`, 완성 폰트는 `89f33b86fa5b8d0ba15e6a81cb7b8595483879db711f9a1b582b07c59126c069`입니다.

이 정확한 HDI·폰트·Anex86 조합에서는 `자! 오늘도 벌자!!` 대사가 읽을 수 있는 한국어로 확인됐습니다. 메뉴 전 FMX/SGS 초기화 문구 일부는 일본어로 남아 있고, 선택한 16×16 한글 글꼴은 가독성에 한계가 있습니다.
