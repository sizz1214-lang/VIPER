#!/usr/bin/env python3
"""Apply the sealed VIPER BTR Korean HDI and font xdelta patches."""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path


SOURCE_HDI_SHA256 = "dbc91f5d15eb7fb5400b6c82bc904223eb03f186280e8e7d94dede65cb755ef0"
TARGET_HDI_SHA256 = "6c9fde1b237bf9dcb003b85a379264e2a4a53b2815aeb2809d9c458b3de0e479"
SOURCE_FONT_SHA256 = "acc7a7713c8142e5a1256783502f3ecce06873a46b160c2d00956ff977955660"
TARGET_FONT_SHA256 = "89f33b86fa5b8d0ba15e6a81cb7b8595483879db711f9a1b582b07c59126c069"
HDI_PATCH_SHA256 = "1385e9eb6624693f5e4cde98887e0481d20104091684817bb6e313b501cf6379"
FONT_PATCH_SHA256 = "880bb85c1e2be89e3ca2485d627aa760440fe6f70607259fdb2b6e018206ae17"


class PatchError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify(path: Path, expected: str, label: str) -> None:
    if not path.is_file():
        raise PatchError(f"{label} 파일을 찾지 못했습니다: {path}")
    actual = sha256(path)
    if actual != expected:
        raise PatchError(
            f"{label} 해시가 맞지 않습니다.\n"
            f"  기대값: {expected}\n"
            f"  실제값: {actual}\n"
            "다른 버전이거나 이미 수정된 파일에는 적용하지 않습니다."
        )


def find_xdelta(script_dir: Path) -> str:
    local_names = ("xdelta3.exe", "xdelta3") if os.name == "nt" else ("xdelta3",)
    for name in local_names:
        candidate = script_dir / name
        if candidate.is_file():
            return str(candidate)
    command = shutil.which("xdelta3")
    if command:
        return command
    raise PatchError(
        "xdelta3를 찾지 못했습니다. Windows에서는 xdelta3.exe를 이 스크립트와 "
        "같은 폴더에 두고, Linux에서는 xdelta3 패키지를 설치하십시오."
    )


def apply_one(
    xdelta: str,
    source: Path,
    patch: Path,
    destination: Path,
    source_hash: str,
    patch_hash: str,
    target_hash: str,
    label: str,
) -> None:
    verify(source, source_hash, f"{label} 원본")
    verify(patch, patch_hash, f"{label} 패치")

    if destination.exists():
        if destination.is_file() and sha256(destination) == target_hash:
            print(f"[통과] {destination.name}: 이미 정확한 최종본입니다.")
            return
        raise PatchError(f"출력 경로에 다른 파일이 이미 있습니다: {destination}")

    temporary = destination.with_name(
        f".{destination.name}.{uuid.uuid4().hex}.building"
    )
    try:
        result = subprocess.run(
            [xdelta, "-d", "-f", "-s", str(source), str(patch), str(temporary)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise PatchError(
                f"{label} xdelta 적용 실패(종료 코드 {result.returncode}):\n"
                f"{result.stderr[:1000]}"
            )
        verify(temporary, target_hash, f"{label} 적용 결과")
        os.replace(temporary, destination)
        print(f"[통과] {destination.name}: {target_hash}")
    finally:
        if temporary.exists():
            temporary.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="VIPER BTR 일본어 원본 HDI와 FONT.BMP에 한국어 xdelta를 적용합니다."
    )
    parser.add_argument("hdi", type=Path, help="원본 ROMS/Viper BTR.hdi")
    parser.add_argument("font", type=Path, help="원본 FONT.BMP (hangul.bmp가 아님)")
    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        default=Path("patched_output"),
        help="출력 폴더(기본값: ./patched_output)",
    )
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    hdi_patch = script_dir / "Viper_BTR_Korean_Final_v1.xdelta"
    font_patch = script_dir / "Viper_BTR_Korean_Font_v1.xdelta"
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        xdelta = find_xdelta(script_dir)
        apply_one(
            xdelta,
            args.hdi.resolve(),
            hdi_patch,
            output_dir / "Viper BTR_kor.hdi",
            SOURCE_HDI_SHA256,
            HDI_PATCH_SHA256,
            TARGET_HDI_SHA256,
            "HDI",
        )
        apply_one(
            xdelta,
            args.font.resolve(),
            font_patch,
            output_dir / "hangul.bmp",
            SOURCE_FONT_SHA256,
            FONT_PATCH_SHA256,
            TARGET_FONT_SHA256,
            "폰트",
        )
    except PatchError as error:
        print(f"[실패] {error}", file=sys.stderr)
        return 3

    print(f"완료: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
